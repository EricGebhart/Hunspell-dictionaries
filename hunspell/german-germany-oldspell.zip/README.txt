Spell checking (old spelling)
=============================
Author:
(C) 2011 R�diger Br�nner (Version: 2011-10-19)
derived from igerman98 and frami dictionaries:

Copyright 
(C) 1998-2011 Bjoern Jacke <bjoern@j3e.de> 
(C) 1998-2011 Franz Michael Baumann <frami.baumann@web.de>

Modified according to the classical spelling rules and
very enlarged by technical, chemical and physical terms by
(C) 2010-2011	R�diger Br�nner (Version: 2011-10-19)
License: GNU General Public License (GPL v. 2 or 3)
