2008-01-10
 السلام عليكم،

  In the package, two files of the Arabic spellchecker dictionary, hunspell-ar, from Ayaspell project in the final version (the two files are ar.dic and ar.aff) witch are working with Hunspell (version >= 1.1.2) of the suite office: OpenOffice.org.

  The author of the dictionary assumes no responsibility if any files are corrupts or if any malfunction appear in your system as a result of its installation or use.
  
  The dictionary is under three licences: GPL/LGPL/MPL

  Site: http://ayaspell.sourceforge.net/
  Mailing list: http://ayaspell.blogspot.com
  Blog: http://ayaspell.sourceforge.net 
==========================================================================


