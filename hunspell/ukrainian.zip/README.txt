This is Ukrainian spelling dictionary for myspell & hunspell version 1.6.0.

This dictionary based on spell-uk project http://ispell-uk.sourceforge.net/


Copyright (C) 1999
    Vladimir Yakovchuk
    Oleg Podgurniy
    
Copyright (C) 2001 
    Dmytro Kovalyov
    Maksym Polyakov
    Andriy Rysin

Copyright (C) 2002
    Valentyn Solomko
    Volodymyr M. Lisivka
    
Copyright (C) 2005
    Andriy Rysin
    Eugeniy Meshcheryakov
    Dmytro Kovalyov

Copyright (C) 2006-2009
    Andriy Rysin

This dictionary is licensed under GPL 2.0 or above, LGPL 2.1 or above and MPL (Mozilla Public License) 1.1 licenses.
