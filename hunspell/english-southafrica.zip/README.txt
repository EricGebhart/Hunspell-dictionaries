English (South Africa) Language Dictionary

Dictionary from Translate.org.za
http://translate.org.za/
