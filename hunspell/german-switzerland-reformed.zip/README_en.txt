This spell-checking dictionary is based on:

de-CH_frami
Version: 2011-05-05
Author:  Franz Michael Baumann <frami.baumann@web.de>
License: GNU GPL Version 2 or GPL Version 3 or OASIS 0.1

It contains the complete word list of Bj�rn Jacke's "igerman98" 
(Version: 2011-03-21) and numerous supplements by Franz Michael 
Baumann according to the reform of 2006-08-01.
