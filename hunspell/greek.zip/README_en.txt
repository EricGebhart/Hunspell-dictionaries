Greek dictionary pack
=========================

Version: 1.0.0
Revision: October, 22, 2008

Prepeared (assembled together) by:
Panos Papadimitriou <ppapadim@optis.gr>

Open Source (GPL or LGPL may apply):
See all the README_*.txt files to see the actual
license types and conditions for all the
dictionaries included.