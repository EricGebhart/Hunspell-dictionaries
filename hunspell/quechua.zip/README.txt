Myspell dictionary
------------------

Language: Shukyachiska Kichwa del Ecuador (qu_EC)
Origin:   Written from scratch by collecting words from various media.
License:  GNU AFFERO GENERAL PUBLIC LICENSE version 3
Author:   Arno Teigseth and Henry David Lara de la Bastida
Version:  0.9
-------------------------------------------------------------
  NB! Before ooo 3.2 there is no language list box entry for Kichwa
-------------------------------------------------------------
This version is an early release, and is by no means complete.
