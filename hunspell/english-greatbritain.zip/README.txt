This dictionary was initially based on a subset of the 
original English wordlist created by Kevin Atkinson for 
Pspell and  Aspell and thus is covered by his original 
LGPL licence. 

It has been extensively updated by David Bartlett, Brian Kelk
and Andrew Brown:
- numerous Americanism have been removed
- numerous American spellings have been corrected
- missing words have been added
- many errors have been corrected
- compound hyphenated words have been added where appropriate

Valuable inputs to this process were received from many other 
people - far too numerous to name. Serious thanks to you all
for your greatly appreciated help.

This word list is intended to be a good representation of
current modern British English and thus it should be a good 
basis for Commonwealth English in most countries of the world 
outside North America.

The affix file has been created completely from scratch
by David Bartlett and Andrew Brown, based on the published 
rules for MySpell and is also provided under the LGPL.

In creating the affix rules an attempt has been made to 
reproduce the most general rules for English word
formation, rather than merely use it as a means to
compress the size of the dictionary. It is hoped that this
will facilitate future localisation to other variants of
English.

Please let David Bartlett <dwb@openoffice.org> know of any 
errors that you find.

The current release is R 1.20, 30/11/2006
