﻿This dictionary for spell-checking Czech texts is licensed under GPL license.

The dictionary is based on Czech ispell dictionary created by Petr Kolar
and numerous contributors.
