This Macedonian dictionary was created by:
Taras Bendik

The Macedonian dictionary is covered by the GNU GPL License and 
supports Macedonian language (mk_MK)

Project was realized by Free/Libre Software Organisation of Macedonia (OSSM).

Bug report: <vladoboss@mt.net.mk
