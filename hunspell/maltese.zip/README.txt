Libreoffice Maltese Spellchecker
------------------------------
http://linux.org.mt/projects/spellcheck

1. About
========

This spell checker comes from the Maltese spell checker project. Actually, the original spell checker is for aspell.
This project provides the Maltese word list for it. Any software that interfaces with aspell can do spell checking in Maltese.
This includes most text-processing Linux applications.
Original aspell dictionary: http://linux.org.mt/downloads/aspell6-mt-0.4.tar.bz2

Original Word List By: Ramon Casha <ramon.casha at linux.org.mt>

1. Copyright
============

Maltese Wordlist & Affix file
-------------------------------

Copyright (c) 2002-2009 by Ramon Casha (ramon.casha 'at' linux.org.mt) under the LGPL.

LibreOffice Packaging
---------------------

Philip Serracino Inglott (phsi 'at' inkwina.net)


3. Contributing
===============

You can help to make this software better.

If you find errors in the spellchecker or have wordlists that you would like to
contribute to the spellchecker or if you would like to extend the affix file 
then contact contrib@spellcheck.linux.org.mt
