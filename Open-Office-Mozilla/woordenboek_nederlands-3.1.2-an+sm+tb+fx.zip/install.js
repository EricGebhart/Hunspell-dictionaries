﻿var err = initInstall("Dit woordenboek Nederlands voor de spellingcontrole in Mozilla-producten is gebaseerd op de woordenlijst 2.10G van OpenTaal. Het product volgt de regels en principes van de officiële spelling en draagt het Keurmerk Spelling van de Nederlandse Taalunie. Voor meer informatie zie: http://www.taalunieversum.org/spelling/keurmerk/", "nl-NL@dictionaries.addons.mozilla.org", "3.1.0");
if (err != SUCCESS)
    cancelInstall();

var fProgram = getFolder("Program");
err = addDirectory("", "nl-NL@dictionaries.addons.mozilla.org",
		   "dictionaries", fProgram, "dictionaries", true);
if (err != SUCCESS)
    cancelInstall();

performInstall();