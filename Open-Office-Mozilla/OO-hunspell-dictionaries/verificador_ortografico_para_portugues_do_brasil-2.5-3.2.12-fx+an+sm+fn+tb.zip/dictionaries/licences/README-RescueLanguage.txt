Esta wordlist é modificada pelo time do Rescue Language
suas principais modificações são inclusão de novas palavras
correção de palavras e compatibilidade com outros aplicativos.
Acesse o site para mais informações:
http://rescuelanguage.sf.net (English)
